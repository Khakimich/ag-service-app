<?php
// AUTOGROM: загрузка каталога услуг (описания + картинки) через job-bridge.
// Запуск: php svc_import.php          — пробный прогон, ничего не меняет
//         php svc_import.php --apply  — применить изменения
$apply = in_array('--apply', $argv, true);
$root  = '/home/khakimjon/web/job.autogrom.ru/public_html';
$imgBase = 'https://job.autogrom.ru/svc_img/';
define('AG_SERVICE_INTERNAL', true);
$key = trim((string)require $root . '/ag_service_bridge_secret.php');
if ($key === '') { fwrite(STDERR, "Нет ключа job-bridge\n"); exit(1); }

function req($m, $path, $body = null) {
    global $key;
    $ch = curl_init('https://api.autogrom-group.com/api/business/job-bridge/' . $path);
    $h = ['Accept: application/json', 'X-AG-Job-Key: ' . $key];
    if ($body !== null) { $h[] = 'Content-Type: application/json'; curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE)); }
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $m, CURLOPT_HTTPHEADER => $h, CURLOPT_TIMEOUT => 30]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return [$code, json_decode((string)$raw, true), $raw];
}
function payload($s, $over) {
    $p = [
        'title' => (string)$s['title'],
        'description' => (string)($s['description'] ?? ''),
        'price_from' => (float)($s['price_from'] ?? 0),
        'price_fixed' => (bool)($s['price_fixed'] ?? false),
        'duration_minutes' => max(1, (int)($s['duration_minutes'] ?? 30)),
        'photo_url' => (string)($s['photo_url'] ?? ''),
    ];
    if (array_key_exists('price_to', $s) && $s['price_to'] !== null) $p['price_to'] = (float)$s['price_to'];
    if (array_key_exists('discount_tag', $s)) $p['discount_tag'] = $s['discount_tag'];
    if (array_key_exists('discount_price', $s) && $s['discount_price'] !== null) $p['discount_price'] = (float)$s['discount_price'];
    return array_merge($p, $over);
}

$data = json_decode(file_get_contents(__DIR__ . '/catalog_import.json'), true);
[$code, $list] = req('GET', 'services-admin');
if ($code !== 200 || empty($list['services'])) { fwrite(STDERR, "Не удалось получить услуги: HTTP $code\n"); exit(1); }
$byId = []; $byTitle = [];
foreach ($list['services'] as $s) { $byId[$s['id']] = $s; $byTitle[mb_strtolower(trim($s['title']))] = $s; }
$bk = '/root/svc_backup_' . date('Ymd_His') . '.json';
file_put_contents($bk, json_encode($list['services'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
echo "Сейчас услуг: " . count($byId) . ". Резервная копия: $bk\n";
echo $apply ? "РЕЖИМ: ПРИМЕНЕНИЕ\n" : "РЕЖИМ: ПРОБНЫЙ (ничего не меняется). Для записи: php svc_import.php --apply\n";

$st = ['upd' => 0, 'new' => 0, 'photo' => 0, 'err' => 0];
foreach ($data['items'] as $it) {
    $photo = $imgBase . $it['img'] . '.png';
    $cur = null;
    if ($it['old_id'] && isset($byId[$it['old_id']])) $cur = $byId[$it['old_id']];
    elseif (isset($byTitle[mb_strtolower(trim($it['title']))])) $cur = $byTitle[mb_strtolower(trim($it['title']))];
    $over = ['title' => $it['title'], 'description' => $it['description'], 'price_from' => (float)$it['price_from'],
             'duration_minutes' => (int)$it['duration_minutes'], 'photo_url' => $photo];
    if ($cur) {
        $st['upd']++;
        if ($apply) { [$c, $r, $raw] = req('PUT', 'services-admin/' . $cur['id'], payload($cur, $over)); if ($c >= 300) { $st['err']++; echo "ОШИБКА $c {$it['title']}: " . substr($raw, 0, 150) . "\n"; } }
    } else {
        $st['new']++;
        if ($apply) { [$c, $r, $raw] = req('POST', 'services-admin', payload(['price_fixed' => false], $over)); if ($c >= 300) { $st['err']++; echo "ОШИБКА $c {$it['title']}: " . substr($raw, 0, 150) . "\n"; } }
    }
}
foreach ($data['old_photos'] as $id => $img) {
    if (empty($byId[$id])) continue;
    $s = $byId[$id];
    if (trim((string)($s['photo_url'] ?? '')) !== '') continue; // своё фото не трогаем
    $st['photo']++;
    if ($apply) { [$c, $r, $raw] = req('PUT', 'services-admin/' . $id, payload($s, ['photo_url' => $imgBase . $img . '.png'])); if ($c >= 300) { $st['err']++; echo "ОШИБКА $c {$s['title']}: " . substr($raw, 0, 150) . "\n"; } }
}
echo "Обновить существующих: {$st['upd']}\nДобавить новых: {$st['new']}\nКартинки старым услугам: {$st['photo']}\nОшибок: {$st['err']}\n";
if ($apply) { @array_map('unlink', glob(dirname($root) . '/private/ag_cache/svc_*.json')); echo "Кэш услуг на сайте очищен.\n"; }
